import React from 'react'

export const ArtValue = () => {
  return <div>ArtValue</div>
}

export default ArtValue
