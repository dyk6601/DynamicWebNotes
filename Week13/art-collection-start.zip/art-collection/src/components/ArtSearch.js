import React from 'react'

const ArtSearch = () => {
  return <div>ArtSearch</div>
}

export default ArtSearch
